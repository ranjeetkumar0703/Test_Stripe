package com.Comment._1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Comment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
