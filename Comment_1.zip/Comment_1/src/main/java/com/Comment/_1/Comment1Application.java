package com.Comment._1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Comment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Comment1Application.class, args);
	}

}
