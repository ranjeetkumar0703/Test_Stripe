package com.Post_1.Post_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Post1Application {

	public static void main(String[] args) {
		SpringApplication.run(Post1Application.class, args);
	}

}
