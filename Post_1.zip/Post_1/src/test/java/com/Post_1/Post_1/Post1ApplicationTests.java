package com.Post_1.Post_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Post1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
