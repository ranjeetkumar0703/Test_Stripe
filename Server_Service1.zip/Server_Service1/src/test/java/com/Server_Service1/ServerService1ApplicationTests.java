package com.Server_Service1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
