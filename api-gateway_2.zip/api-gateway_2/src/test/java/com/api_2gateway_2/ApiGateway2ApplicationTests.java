package com.api_2gateway_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateway2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
